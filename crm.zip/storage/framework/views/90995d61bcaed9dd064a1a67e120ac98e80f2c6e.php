

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="animated fadeIn">
    <div class='col-lg-12'>
       <img src="<?php echo e(asset('backend/images/alert.png')); ?>" class="alert">
        <h4><center>401<br>
        You are not authorized to access this page</center></h4>
    </div>
  </div>
</div>
<style>
.alert {
  display:block;
  margin:auto;
  height:100px;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\CMMA\resources\views/errors/401.blade.php ENDPATH**/ ?>