

<?php $__env->startSection('title', '| Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="animated fadeIn">
    <div class="col-lg-12">
    <div class="card-box">
    <h3> User Administration <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-default pull-right">Roles</a>
    <!-- <a href="" class="btn btn-default pull-right">Permissions</a> -->
</h3>
    <hr>
    <div class="table-responsive">
        <table class="table table-bordered table-striped">

            <thead>
                <tr>
                    <th>Sl No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Date/Time Added</th>
                    <th>User Roles</th>
                    <th>Operations</th>
                </tr>
            </thead>

            <tbody>
                <?php 
                $i = 1;
                ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($i); ?> </td>
                    <td><?php echo e($user->fullname); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->created_at->format('F d, Y h:ia')); ?></td>
                    <td><?php echo e($user->roles()->pluck('name')->implode(' ')); ?></td>
                    <td>
                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-info pull-left" style="margin-right: 3px;">Edit</a>

                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id] ]); ?>

                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>


                    </td>
                </tr>
                <?php 
                $i++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>

    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success">Add User</a>
</div>
  </div>
 </div>
</div>
<style>
.card-box {
    padding:20px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\crm\resources\views/users/index.blade.php ENDPATH**/ ?>